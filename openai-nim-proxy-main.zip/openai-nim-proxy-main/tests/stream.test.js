const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const { Readable } = require('stream');

const projectRoot = path.resolve(__dirname, '..');
let source = fs.readFileSync(path.join(projectRoot, 'server.js'), 'utf8');
source += '\nmodule.exports.__test = { handleStream };';

function fakeExpress() {
  return { use() {}, get() {}, post() {}, listen() {} };
}
fakeExpress.json = () => function noop() {};
fakeExpress.urlencoded = () => function noop() {};

const sandbox = {
  Buffer,
  console,
  __dirname: projectRoot,
  module: { exports: {} },
  exports: {},
  process: { env: {} },
  require(id) {
    if (id === 'express') return fakeExpress;
    if (id === 'cors') return () => function noop() {};
    if (id === 'axios') return { post() { throw new Error('Network disabled in tests'); } };
    return require(id);
  }
};

vm.runInNewContext(source, sandbox, { filename: path.join(projectRoot, 'server.js') });
const { handleStream } = sandbox.module.exports.__test;

function event(content) {
  return 'data: ' + JSON.stringify({ choices: [{ delta: { content } }] }) + '\n\n';
}

async function main() {
  const block = '<!-- GFX_START -->\n<internal_states><details><summary>🎬 INTERNAL STATES</summary><details><summary>📓 GM\'S NOTEBOOK</summary>- [R] State</details></details></internal_states>\n<!-- GFX_END -->';
  const input = Readable.from([
    'data: ' + JSON.stringify({ choices: [{ delta: { role: 'assistant' } }] }) + '\n\n',
    event('Narrative text.\n\n<!-- GFX_STA'),
    event('RT -->' + block.slice('<!-- GFX_START -->'.length, 95)),
    event(block.slice(95)),
    'data: [DONE]\n\n'
  ]);

  const writes = [];
  await new Promise((resolve, reject) => {
    const response = {
      headersSent: false,
      setHeader() {},
      write(value) { writes.push(value); },
      end() { resolve(); },
      status() { return this; },
      json() { reject(new Error('Unexpected JSON error response')); }
    };
    input.on('error', reject);
    handleStream(input, response, 'default', true);
  });

  const joined = writes.join('');
  const emittedContent = joined.split(/\n\n/).reduce((combined, frame) => {
    if (!frame.startsWith('data: {')) return combined;
    const parsed = JSON.parse(frame.slice(6));
    const delta = (((parsed.choices || [])[0] || {}).delta || {});
    return combined + (delta.content || '');
  }, '');
  assert(emittedContent.includes('Narrative text.'), 'Narrative should stream through');
  assert(emittedContent.includes('style='), 'Completed FF5 UI block should receive display styling');
  assert.strictEqual((joined.match(/data: \[DONE\]/g) || []).length, 1, 'Stream should end with exactly one DONE event');
  assert(joined.lastIndexOf('style=') < joined.lastIndexOf('data: [DONE]'), 'Buffered UI must be emitted before DONE');

  console.log('FF5 streaming transform tests passed.');
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
