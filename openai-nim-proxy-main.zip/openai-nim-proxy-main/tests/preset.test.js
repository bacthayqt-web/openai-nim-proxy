const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const projectRoot = path.resolve(__dirname, '..');
const serverPath = path.join(projectRoot, 'server.js');
let source = fs.readFileSync(serverPath, 'utf8');
source += '\nmodule.exports.__test = { expandPresetMacros, buildOrderedMessagesFromPreset, prepareFF5History, applyFrontendDisplay, PRESET_FRANKENSTEIN, PROMPT_OVERRIDES };';

function fakeExpress() {
  return {
    use() {},
    get() {},
    post() {},
    listen() {}
  };
}
fakeExpress.json = () => function noop() {};
fakeExpress.urlencoded = () => function noop() {};

const sandbox = {
  Buffer,
  console,
  __dirname: projectRoot,
  module: { exports: {} },
  exports: {},
  process: { env: {} },
  require(id) {
    if (id === 'express') return fakeExpress;
    if (id === 'cors') return () => function noop() {};
    if (id === 'axios') return { post() { throw new Error('Network disabled in tests'); } };
    return require(id);
  }
};

vm.runInNewContext(source, sandbox, { filename: serverPath });
const api = sandbox.module.exports.__test;

const originalMessages = [
  { role: 'system', content: 'Character card system prompt.' },
  { role: 'user', content: 'Continue the scene.' }
];

const generic = api.buildOrderedMessagesFromPreset(api.PRESET_FRANKENSTEIN, originalMessages, {});
const genericSystem = generic.find((message) => message.role === 'system').content;
assert(genericSystem.includes('<details>'), 'Generic profile should retain FF5 HTML status templates');
assert(genericSystem.includes('<gfx_protocol>'), 'Generic profile should retain FF5 graphics protocol');
assert(genericSystem.includes('3rd person'), 'Third-person POV prompt should be present');
assert(!genericSystem.includes('Hybrid POV'), 'Hybrid POV should not be present');
assert(!/\{\{(?:setvar|getvar|roll|trim)(?:::|\}\})/.test(genericSystem), 'Known SillyTavern macros should be compiled');
assert(!genericSystem.includes('{{//'), 'SillyTavern prompt comments should be removed');

const janitor = api.buildOrderedMessagesFromPreset(
  api.PRESET_FRANKENSTEIN,
  originalMessages,
  api.PROMPT_OVERRIDES.janitor
);
const janitorSystem = janitor.find((message) => message.role === 'system').content;
assert(janitorSystem.includes('## 🎬 Internal States'), 'Janitor should receive Markdown status template');
assert(janitorSystem.includes('frontend-safe Markdown'), 'Janitor should receive Markdown graphics protocol');
assert(!janitorSystem.includes('<!-- GFX_START -->'), 'Janitor override should not emit GFX wrappers');
assert(!janitorSystem.includes('<details>'), 'Janitor override should not emit HTML details blocks');
assert(!/\{\{(?:setvar|getvar|roll|trim)(?:::|\}\})/.test(janitorSystem), 'Janitor macros should be compiled');
assert(!janitorSystem.includes('{{//'), 'Janitor prompt comments should be removed');

const sample = '<!-- GFX_START -->\n<internal_states><details><summary>🎬 INTERNAL STATES</summary><details><summary>📓 GM\'S NOTEBOOK</summary>- [R] Keep this</details></details></internal_states>\n<!-- GFX_END -->';
const styled = api.applyFrontendDisplay(sample, 'default', true);
assert(styled.includes('style='), 'Generic FF5 display regex should add inline styles');
assert.strictEqual(api.applyFrontendDisplay(sample, 'janitor', true), sample, 'Janitor output should bypass FF5 HTML display regex');

const history = [
  { role: 'assistant', content: sample },
  { role: 'user', content: 'Next turn' },
  { role: 'assistant', content: sample },
  { role: 'user', content: 'Current turn' }
];
const cleanedHistory = api.prepareFF5History(history);
assert(!cleanedHistory[0].content.includes('<internal_states>'), 'Older Internal States should be removed from model context');
assert(cleanedHistory[2].content.includes('<internal_states>'), 'Most recent Internal States should remain available to the model');

console.log('FF5 universal preset tests passed.');
